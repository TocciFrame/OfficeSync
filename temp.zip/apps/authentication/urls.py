from django.urls import path
from .views import login_view, register_view, logout_view

app_name = "authentication"

urlpatterns = [
    path("", login_view, name="login"),             
    path("login/", login_view),                     
    path("register/", register_view, name="register"), 
    path("logout/", logout_view, name="logout"),      
]