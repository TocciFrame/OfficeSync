"""
URL configuration for officesync project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(('apps.landing.urls', 'landing'), namespace='landing')),
    path('auth/', include(('apps.authentication.urls', 'authentication'), namespace='authentication')),
    path('profile/', include(('apps.user_profile.urls', 'user_profile'), namespace='user_profile')),
    path('settings/', include(('apps.user_settings.urls', 'user_settings'), namespace='user_settings')),
    path('dashboard/', include(('apps.dashboard.urls', 'dashboard'), namespace='dashboard')),
]